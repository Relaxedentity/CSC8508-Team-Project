#include "GameWorld.h"

using namespace NCL::PS4;

GameWorld::GameWorld() {
	mainCamera = new Camera();

	worldIDCounter = 0;
	worldStateCounter = 0;
}

GameWorld::~GameWorld() {
	renderObjects.erase(renderObjects.begin(), renderObjects.end());
}

void GameWorld::Clear() {
	renderObjects.erase(renderObjects.begin(), renderObjects.end());
	worldIDCounter = 0;
	worldStateCounter = 0;
}

void GameWorld::AddRenderObject(RenderObject* o) {
	renderObjects.emplace_back(o);
	worldIDCounter++;
	//o->SetWorldID(worldIDCounter++);
	worldStateCounter++;
	std::cout << "GameWorld: " << renderObjects.size() << std::endl;
}

void GameWorld::OperateOnContents(RenderObjectFunc f) {
	for (RenderObject* g : renderObjects) {
		f(g);
	}
}