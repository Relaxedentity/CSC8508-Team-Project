#pragma once
#include "RenderObject.h"
#include "../Common/Camera.h"
#include <functional>
#include <vector>

namespace NCL {
	namespace PS4 {
		typedef std::function<void(RenderObject*)> RenderObjectFunc;
		class GameWorld {
		public:
			GameWorld();
			~GameWorld();

			void AddRenderObject(RenderObject* o);
			void OperateOnContents(RenderObjectFunc f);
			void Clear();

			Camera* GetMainCamera() { return mainCamera; }
		protected:
			std::vector<RenderObject*> renderObjects;
			Camera* mainCamera;

			int		worldIDCounter;
			int		worldStateCounter;
		};
	}
}