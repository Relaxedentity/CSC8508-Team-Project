#pragma once
#include "../Plugins/PlayStation4/PS4RendererBase.h"
#include "GameWorld.h"
#include <vector>

namespace NCL {
	namespace PS4 {
		class ExampleRenderer :
			public PS4RendererBase
		{
		public:
			ExampleRenderer(PS4Window* window, GameWorld* world);
			~ExampleRenderer();

			void Update(float dt)	 override;

		protected:
			void	RenderFrame()	override;

			void BuildObjectList();
			void DrawRenderObject(RenderObject* o);

			GameWorld* gameWorld;
			std::vector<RenderObject*> activeObjects;

			//		
			NCL::Maths::Matrix4*	viewProjMat;
			Gnm::Buffer	cameraBuffer;
		};
	}
}

