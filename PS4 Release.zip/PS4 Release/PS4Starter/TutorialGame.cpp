#include "TutorialGame.h"
#include "../Plugins/PlayStation4/PS4Mesh.h"
#include "../Plugins/PlayStation4/PS4Shader.h"
#include "RenderObject.h"
#include "../Common/Vector3.h"
#include "../Common/Quaternion.h"
#include "../Plugins/PlayStation4/PS4Input.h"

using namespace NCL;
using namespace NCL::PS4;
using namespace NCL::Maths;

TutorialGame::TutorialGame() {
	world = new GameWorld();

	renderer = new ExampleRenderer((PS4Window*)Window::GetWindow(), world);

	InitialiseAssets();
}

void TutorialGame::InitialiseAssets() {
	//quadMesh = PS4Mesh::GenerateQuad();
	cubeMesh = new PS4Mesh("/app0/Assets/Meshes/cube.msh");
	sphereMesh = new PS4Mesh("/app0/Assets/Meshes/sphere.msh");
	charMesh = new PS4Mesh("/app0/Assets/Meshes/goat.msh");
	enemyMesh = new PS4Mesh("/app0/Assets/Meshes/Keeper.msh");
	bonusMesh = new PS4Mesh("/app0/Assets/Meshes/coin.msh");
	capsuleMesh = new PS4Mesh("/app0/Assets/Meshes/capsule.msh");
	gooseMesh = new PS4Mesh("/app0/Assets/Meshes/goose.msh");
	playerMesh = new PS4Mesh("/app0/Assets/Meshes/splatPlayer.msh");
	catMesh = new PS4Mesh("/app0/Assets/Meshes/SanctumCat.msh");
	corridorStraightMesh = new PS4Mesh("/app0/Assets/Meshes/corridor_Wall_Straight_Mid_end_L.msh");
	corridorCornerRightSideMesh = new PS4Mesh("/app0/Assets/Meshes/Corridor_Wall_Corner_Out_L.msh");
	corridorCornerLeftSideMesh = new PS4Mesh("/app0/Assets/Meshes/Corridor_Wall_Corner_Out_R.msh");

	//quadMesh->UploadToGPU(renderer);
	cubeMesh->UploadToGPU(renderer);
	sphereMesh->UploadToGPU(renderer);
	charMesh->UploadToGPU(renderer);
	enemyMesh->UploadToGPU(renderer);
	bonusMesh->UploadToGPU(renderer);
	capsuleMesh->UploadToGPU(renderer);
	gooseMesh->UploadToGPU(renderer);
	playerMesh->UploadToGPU(renderer);
	catMesh->UploadToGPU(renderer);
	corridorStraightMesh->UploadToGPU(renderer);
	corridorCornerRightSideMesh->UploadToGPU(renderer);
	corridorCornerLeftSideMesh->UploadToGPU(renderer);

	catTex = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/InSanct_Max_Cat_Colour.gnf");
	capsuleTex = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/capsule.gnf");
	terrainTex = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/201215j07c4qx88ax8.thumb.gnf");
	corridorTex = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/corridor_wall_c.gnf");
	basicTex = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/checkerboard.gnf");

	cubeTex1 = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/Cubemap/skyrender0001.gnf");
	cubeTex2 = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/Cubemap/skyrender0002.gnf");
	cubeTex3 = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/Cubemap/skyrender0003.gnf");
	cubeTex4 = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/Cubemap/skyrender0004.gnf");
	cubeTex5 = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/Cubemap/skyrender0005.gnf");
	cubeTex6 = PS4Texture::LoadTextureFromFile("/app0/Assets/Textures/Cubemap/skyrender0006.gnf");

	defaultShader = PS4Shader::GenerateShader(
		"/app0/Assets/Shaders/PS4/VertexShader.sb",
		"/app0/Assets/Shaders/PS4/PixelShader.sb"
	);

	InitCamera();
	InitWorld();
}

TutorialGame::~TutorialGame() {
	delete quadMesh;
	delete cubeMesh;
	delete sphereMesh;
	delete charMesh;
	delete enemyMesh;
	delete bonusMesh;
	delete capsuleMesh;
	delete gooseMesh;
	delete playerMesh;
	delete catMesh;
	delete corridorStraightMesh;
	delete corridorCornerRightSideMesh;
	delete corridorCornerLeftSideMesh;

	delete catTex;
	delete capsuleTex;
	delete terrainTex;
	delete corridorTex;
	delete basicTex;

	delete cubeTex1;
	delete cubeTex2;
	delete cubeTex3;
	delete cubeTex4;
	delete cubeTex5;
	delete cubeTex6;

	delete defaultShader;
}

void TutorialGame::UpdateGame(float dt, PS4Input* input) {
	world->GetMainCamera()->UpdateCamera(dt, input);

	renderer->Update(dt);
	renderer->Render();
}

void TutorialGame::InitCamera() {
	world->GetMainCamera()->SetNearPlane(0.1f);
	world->GetMainCamera()->SetFarPlane(500.0f);
	world->GetMainCamera()->SetPitch(-15.0f);
	world->GetMainCamera()->SetYaw(315.0f);
	world->GetMainCamera()->SetPosition(Vector3(-60, 40, 60));
}

void TutorialGame::InitWorld() {
	//buildSkybox();
	AddPlayerToWorld(Vector3(50, 2, 20), Quaternion(0, 0, 0, 1));
	AddCatToWorld(Vector3(0, 0, -10), Quaternion(0, 0, 0, 1));
	AddCatToWorld(Vector3(0, -10, 0), Quaternion(0, 0, 0, 1));
	AddCatToWorld(Vector3(-10, 0, 0), Quaternion(0, 0, 0, 1));
	AddCatToWorld(Vector3(-10, -10, 0), Quaternion(0, 0, 0, 1));
	AddCatToWorld(Vector3(-10, 0, -10), Quaternion(0, 0, 0, 1));
	//AddRebWallSouthToWorld(Vector3(10, -1, 0));
	//buildGameworld();
}

void TutorialGame::buildSkybox() {
	RenderObject* forward = new RenderObject((MeshGeometry*)quadMesh, (ShaderBase*)defaultShader, (TextureBase*)cubeTex1);
	Matrix4 mat1 = Matrix4::Translation(Vector3(0, 0, -100)) * Matrix4::Scale(Vector3(200, 200, 1));
	forward->SetLocalTransform(mat1);
	world->AddRenderObject(forward);
	RenderObject* backward = new RenderObject((MeshGeometry*)quadMesh, (ShaderBase*)defaultShader, (TextureBase*)cubeTex3);
	Matrix4 mat2 = Matrix4::Translation(Vector3(0, 0, 100)) * Matrix4::Rotation(180, Vector3(0, 1, 0)) * Matrix4::Scale(Vector3(200, 200, 1));
	backward->SetLocalTransform(mat2);
	world->AddRenderObject(backward);
}

void TutorialGame::buildGameworld() {
	worldGrid = new NavigationGrid("/app0/Assets/Data/TestGrid5.txt");
	GridNode* nodes = worldGrid->GetAllNodes();
	int gridwidth = worldGrid->GetGridWidth();
	int gridheight = worldGrid->getGridHeight();
	for (int y = 0; y < gridheight; y++) {
		for (int x = 0; x < gridwidth; x++) {
			GridNode& n = nodes[(gridwidth * y) + x];
			Vector3 Nposition = n.position;
			if (n.type == 'N') continue;
			switch (n.type) {
			case '.':
				AddFloorToWorld(Vector3(Nposition.x, Nposition.y, Nposition.z), Quaternion(0, 0, 0, 1), Vector3(5, 2, 5));
				break;
			case 'x':
				AddRebWallSquareToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 'n':
				AddRebWallNorthToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 's':
				AddRebWallSouthToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 'e':
				AddRebWallEastToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 'w':
				AddRebWallWestToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case '=':
				AddRebWallDualHorizontalToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 'h':
				AddRebWallDualVerticalToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 'u':
				AddRebWallOpeningNorthToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 'm':
				AddRebWallOpeningSouthToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 'c':
				AddRebWallOpeningEastToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case 'd':
				AddRebWallOpeningWestToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case '9':
				AddRebWallCornerNorthEastToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case '7':
				AddRebWallCornerNorthWestToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case '3':
				AddRebWallCornerSouthEastToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			case '1':
				AddRebWallCornerSouthWestToWorld(Vector3(Nposition.x, Nposition.y - 1, Nposition.z));
				break;
			}
		}
	}
}

RenderObject* TutorialGame::AddPlayerToWorld(const NCL::Maths::Vector3& position, const Quaternion& orientation) {
	RenderObject* character = new RenderObject((MeshGeometry*)playerMesh, (ShaderBase*)defaultShader, (TextureBase*)capsuleTex);
	Matrix4 mat = Matrix4::Translation(position) * Matrix4(orientation);
	character->SetLocalTransform(mat);

	world->AddRenderObject(character);

	return character;
}

RenderObject* TutorialGame::AddCatToWorld(const NCL::Maths::Vector3& position, const Quaternion& orientation) {
	TextureBase* tex = position.x < 0 ? (TextureBase*)catTex : position.y < 0 ? (TextureBase*)capsuleTex : (TextureBase*)terrainTex;
	RenderObject* cat = new RenderObject((MeshGeometry*)catMesh, (ShaderBase*)defaultShader, (TextureBase*)tex);
	Matrix4 mat = Matrix4::Translation(position) * Matrix4(orientation);
	cat->SetLocalTransform(mat);

	world->AddRenderObject(cat);
	
	return cat;
}

RenderObject* TutorialGame::AddFloorToWorld(const NCL::Maths::Vector3& position, const Quaternion& orientation, NCL::Maths::Vector3 halfextents) {
	RenderObject* floor = new RenderObject((MeshGeometry*)cubeMesh, (ShaderBase*)defaultShader, (TextureBase*)terrainTex);
	Matrix4 mat = Matrix4::Translation(position) * Matrix4(orientation) * Matrix4::Scale(halfextents * 2);
	floor->SetLocalTransform(mat);

	world->AddRenderObject(floor);

	return floor;
}

RenderObject* TutorialGame::AddRebWallMainToWorld(const NCL::Maths::Vector3& position, const Quaternion& orientation, NCL::Maths::Vector3 scale) {
	RenderObject* wall = new RenderObject((MeshGeometry*)corridorStraightMesh, (ShaderBase*)defaultShader, (TextureBase*)corridorTex);
	Matrix4 mat = Matrix4::Translation(position) * Matrix4(orientation) * Matrix4::Scale(scale);
	wall->SetLocalTransform(mat);

	world->AddRenderObject(wall);

	return wall;
}

RenderObject* TutorialGame::AddRebWallRightToWorld(const NCL::Maths::Vector3& position, const Quaternion& orientation, NCL::Maths::Vector3 scale, bool nodes) {
	RenderObject* wall = new RenderObject((MeshGeometry*)corridorCornerRightSideMesh, (ShaderBase*)defaultShader, (TextureBase*)corridorTex);
	Matrix4 mat = Matrix4::Translation(position) * Matrix4(orientation) * Matrix4::Scale(scale);
	wall->SetLocalTransform(mat);

	world->AddRenderObject(wall);

	return wall;
}

RenderObject* TutorialGame::AddRebWallLeftToWorld(const NCL::Maths::Vector3& position, const Quaternion& orientation, NCL::Maths::Vector3 scale, bool nodes) {
	RenderObject* wall = new RenderObject((MeshGeometry*)corridorCornerLeftSideMesh, (ShaderBase*)defaultShader, (TextureBase*)corridorTex);
	Matrix4 mat = Matrix4::Translation(position) * Matrix4(orientation) * Matrix4::Scale(scale);
	wall->SetLocalTransform(mat);

	world->AddRenderObject(wall);

	return wall;
}

void TutorialGame::AddRebWallSquareToWorld(const NCL::Maths::Vector3& position) {
	AddRebWallLeftToWorld(position + Vector3(-4.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(1, 3, 1), true);
	AddRebWallMainToWorld(position + Vector3(0, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(8, 3, 1));
	AddRebWallRightToWorld(position + Vector3(4.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(1, 3, 1), true);

	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(90, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(5.5, 0, -4.5), realObjectRotation, Vector3(1, 3, 1), false);
	AddRebWallMainToWorld(position + Vector3(5.5, 0, 0), realObjectRotation, Vector3(8, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(5.5, 0, 4.5), realObjectRotation, Vector3(1, 3, 1), false);

	realObjectRotation = Quaternion(Matrix4::Rotation(270, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(-5.5, 0, 4.5), realObjectRotation, Vector3(1, 3, 1), false);
	AddRebWallMainToWorld(position + Vector3(-5.5, 0, 0), realObjectRotation, Vector3(8, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(-5.5, 0, -4.5), realObjectRotation, Vector3(1, 3, 1), false);

	realObjectRotation = Quaternion(Matrix4::Rotation(180, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(-4.5, 0, -5.5), realObjectRotation, Vector3(1, 3, 1), true);
	AddRebWallMainToWorld(position + Vector3(0, 0, -5.5), realObjectRotation, Vector3(8, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(4.5, 0, -5.5), realObjectRotation, Vector3(1, 3, 1), true);
}

void TutorialGame::AddRebWallNorthToWorld(const NCL::Maths::Vector3& position) {
	AddRebWallMainToWorld(position + Vector3(0, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(10, 3, 1));
}

void TutorialGame::AddRebWallSouthToWorld(const NCL::Maths::Vector3& position) {
	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(180, Vector3(0, 1, 0)));
	AddRebWallMainToWorld(position + Vector3(0, 0, -5.5), realObjectRotation, Vector3(10, 3, 1));
}

void TutorialGame::AddRebWallEastToWorld(const NCL::Maths::Vector3& position) {
	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(270, Vector3(0, 1, 0)));
	AddRebWallMainToWorld(position + Vector3(-5.5, 0, 0), realObjectRotation, Vector3(10, 3, 1));
}

void TutorialGame::AddRebWallWestToWorld(const NCL::Maths::Vector3& position) {
	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(90, Vector3(0, 1, 0)));
	AddRebWallMainToWorld(position + Vector3(5.5, 0, 0), realObjectRotation, Vector3(10, 3, 1));
}

void TutorialGame::AddRebWallDualHorizontalToWorld(const NCL::Maths::Vector3& position) {
	AddRebWallMainToWorld(position + Vector3(0, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(10, 3, 1));

	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(180, Vector3(0, 1, 0)));

	AddRebWallMainToWorld(position + Vector3(0, 0, -5.5), realObjectRotation, Vector3(10, 3, 1));
}

void TutorialGame::AddRebWallDualVerticalToWorld(const NCL::Maths::Vector3& position) {
	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(90, Vector3(0, 1, 0)));
	AddRebWallMainToWorld(position + Vector3(5.5, 0, 0), realObjectRotation, Vector3(10, 3, 1));

	realObjectRotation = Quaternion(Matrix4::Rotation(270, Vector3(0, 1, 0)));
	AddRebWallMainToWorld(position + Vector3(-5.5, 0, 0), realObjectRotation, Vector3(10, 3, 1));
}

void TutorialGame::AddRebWallOpeningSouthToWorld(const NCL::Maths::Vector3& position) {
	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(90, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(5.5, 0, -4.5), realObjectRotation, Vector3(1, 3, 1), true);
	AddRebWallMainToWorld(position + Vector3(5.5, 0, 0.5), realObjectRotation, Vector3(9, 3, 1));

	realObjectRotation = Quaternion(Matrix4::Rotation(270, Vector3(0, 1, 0)));

	AddRebWallMainToWorld(position + Vector3(-5.5, 0, 0.5), realObjectRotation, Vector3(9, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(-5.5, 0, -4.5), realObjectRotation, Vector3(1, 3, 1), true);

	realObjectRotation = Quaternion(Matrix4::Rotation(180, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(-4.5, 0, -5.5), realObjectRotation, Vector3(1, 3, 1), false);
	AddRebWallMainToWorld(position + Vector3(0, 0, -5.5), realObjectRotation, Vector3(8, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(4.5, 0, -5.5), realObjectRotation, Vector3(1, 3, 1), false);
}

void TutorialGame::AddRebWallOpeningNorthToWorld(const NCL::Maths::Vector3& position) {
	AddRebWallLeftToWorld(position + Vector3(-4.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(1, 3, 1), false);
	AddRebWallMainToWorld(position + Vector3(0, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(8, 3, 1));
	AddRebWallRightToWorld(position + Vector3(4.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(1, 3, 1), false);

	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(90, Vector3(0, 1, 0)));

	AddRebWallMainToWorld(position + Vector3(5.5, 0, -0.5), realObjectRotation, Vector3(9, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(5.5, 0, 4.5), realObjectRotation, Vector3(1, 3, 1), true);

	realObjectRotation = Quaternion(Matrix4::Rotation(270, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(-5.5, 0, 4.5), realObjectRotation, Vector3(1, 3, 1), true);
	AddRebWallMainToWorld(position + Vector3(-5.5, 0, -0.5), realObjectRotation, Vector3(9, 3, 1));
}

void TutorialGame::AddRebWallOpeningEastToWorld(const NCL::Maths::Vector3& position) {
	AddRebWallLeftToWorld(position + Vector3(-4.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(1, 3, 1), true);
	AddRebWallMainToWorld(position + Vector3(0.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(9, 3, 1));

	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(270, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(-5.5, 0, 4.5), realObjectRotation, Vector3(1, 3, 1), false);
	AddRebWallMainToWorld(position + Vector3(-5.5, 0, 0), realObjectRotation, Vector3(8, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(-5.5, 0, -4.5), realObjectRotation, Vector3(1, 3, 1), false);

	realObjectRotation = Quaternion(Matrix4::Rotation(180, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(-4.5, 0, -5.5), realObjectRotation, Vector3(1, 3, 1), true);
	AddRebWallMainToWorld(position + Vector3(0.5, 0, -5.5), realObjectRotation, Vector3(9, 3, 1));
}

void TutorialGame::AddRebWallOpeningWestToWorld(const NCL::Maths::Vector3& position) {
	AddRebWallMainToWorld(position + Vector3(-0.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(9, 3, 1));
	AddRebWallRightToWorld(position + Vector3(4.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(1, 3, 1), true);

	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(90, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(5.5, 0, -4.5), realObjectRotation, Vector3(1, 3, 1), false);
	AddRebWallMainToWorld(position + Vector3(5.5, 0, 0), realObjectRotation, Vector3(8, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(5.5, 0, 4.5), realObjectRotation, Vector3(1, 3, 1), false);

	realObjectRotation = Quaternion(Matrix4::Rotation(180, Vector3(0, 1, 0)));

	AddRebWallMainToWorld(position + Vector3(-0.5, 0, -5.5), realObjectRotation, Vector3(9, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(4.5, 0, -5.5), realObjectRotation, Vector3(1, 3, 1), true);
}

void TutorialGame::AddRebWallCornerNorthEastToWorld(const NCL::Maths::Vector3& position) {
	AddRebWallLeftToWorld(position + Vector3(-4.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(1, 3, 1), true);
	AddRebWallMainToWorld(position + Vector3(1, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(10, 3, 1));

	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(270, Vector3(0, 1, 0)));

	AddRebWallMainToWorld(position + Vector3(-5.5, 0, -1), realObjectRotation, Vector3(10, 3, 1));
	AddRebWallRightToWorld(position + Vector3(-5.5, 0, 4.5), realObjectRotation, Vector3(1, 3, 1), false);
}

void TutorialGame::AddRebWallCornerNorthWestToWorld(const NCL::Maths::Vector3& position) {
	AddRebWallRightToWorld(position + Vector3(4.5, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(1, 3, 1), true);
	AddRebWallMainToWorld(position + Vector3(-1, 0, 5.5), Quaternion(0, 0, 0, 1), Vector3(10, 3, 1));

	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(90, Vector3(0, 1, 0)));

	AddRebWallMainToWorld(position + Vector3(5.5, 0, -1), realObjectRotation, Vector3(10, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(5.5, 0, 4.5), realObjectRotation, Vector3(1, 3, 1), false);
}

void TutorialGame::AddRebWallCornerSouthEastToWorld(const NCL::Maths::Vector3& position) {
	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(270, Vector3(0, 1, 0)));

	AddRebWallMainToWorld(position + Vector3(-5.5, 0, 1), realObjectRotation, Vector3(10, 3, 1));
	AddRebWallLeftToWorld(position + Vector3(-5.5, 0, -4.5), realObjectRotation, Vector3(1, 3, 1), true);

	realObjectRotation = Quaternion(Matrix4::Rotation(180, Vector3(0, 1, 0)));

	AddRebWallRightToWorld(position + Vector3(-4.5, 0, -5.5), realObjectRotation, Vector3(1, 3, 1), false);
	AddRebWallMainToWorld(position + Vector3(1, 0, -5.5), realObjectRotation, Vector3(10, 3, 1));
}

void TutorialGame::AddRebWallCornerSouthWestToWorld(const NCL::Maths::Vector3& position) {
	Quaternion realObjectRotation = Quaternion(Matrix4::Rotation(90, Vector3(0, 1, 0)));

	AddRebWallMainToWorld(position + Vector3(5.5, 0, 1), realObjectRotation, Vector3(10, 3, 1));
	AddRebWallRightToWorld(position + Vector3(5.5, 0, -4.5), realObjectRotation, Vector3(1, 3, 1), true);

	realObjectRotation = Quaternion(Matrix4::Rotation(180, Vector3(0, 1, 0)));

	AddRebWallLeftToWorld(position + Vector3(4.5, 0, -5.5), realObjectRotation, Vector3(1, 3, 1), false);
	AddRebWallMainToWorld(position + Vector3(-1, 0, -5.5), realObjectRotation, Vector3(10, 3, 1));
}