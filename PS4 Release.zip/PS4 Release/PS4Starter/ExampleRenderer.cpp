#include "ExampleRenderer.h"
#include "RenderObject.h"
#include "../Plugins/PlayStation4/PS4Mesh.h"
#include "../Plugins/PlayStation4/PS4Shader.h"
#include "../Plugins/PlayStation4/PS4Texture.h"
#include "../Common/Matrix4.h"

using namespace NCL;
using namespace NCL::PS4;

ExampleRenderer::ExampleRenderer(PS4Window* window, GameWorld* world) : PS4RendererBase(window)
{
	gameWorld = world;

	viewProjMat = (Matrix4*)onionAllocator->allocate(sizeof(Matrix4), Gnm::kEmbeddedDataAlignment4);
	*viewProjMat = world->GetMainCamera()->BuildViewMatrix() * world->GetMainCamera()->BuildProjectionMatrix();

	cameraBuffer.initAsConstantBuffer(viewProjMat, sizeof(Matrix4));
	cameraBuffer.setResourceMemoryType(Gnm::kResourceMemoryTypeRO); // it's a constant buffer, so read-only is OK
}

ExampleRenderer::~ExampleRenderer()
{
}

void ExampleRenderer::Update(float dt)	{
}

void ExampleRenderer::BuildObjectList() {
	activeObjects.clear();

	gameWorld->OperateOnContents(
		[&](RenderObject* o) {
			activeObjects.emplace_back(o);
		}
	);

	std::cout << "Renderer: " << activeObjects.size() << std::endl;
}

void ExampleRenderer::RenderFrame() {
	BuildObjectList();
	currentFrame->StartFrame();

	for (auto i : activeObjects) {
		currentGFXContext->waitUntilSafeForRendering(videoHandle, currentGPUBuffer);

		SetRenderBuffer(currentPS4Buffer, true, true, true);


		//Primitive Setup State
		Gnm::PrimitiveSetup primitiveSetup;
		primitiveSetup.init();
		primitiveSetup.setCullFace(Gnm::kPrimitiveSetupCullFaceNone);
		primitiveSetup.setFrontFace(Gnm::kPrimitiveSetupFrontFaceCcw);
		//primitiveSetup.setPolygonMode()
		currentGFXContext->setPrimitiveSetup(primitiveSetup);

		////Screen Access State
		Gnm::DepthStencilControl dsc;
		dsc.init();
		dsc.setDepthControl(Gnm::kDepthControlZWriteEnable, Gnm::kCompareFuncLessEqual);
		dsc.setDepthEnable(true);
		currentGFXContext->setDepthStencilControl(dsc);

		Gnm::Sampler trilinearSampler;
		trilinearSampler.init();
		trilinearSampler.setMipFilterMode(Gnm::kMipFilterModeLinear);

		currentGFXContext->setTextures(Gnm::kShaderStagePs, 0, 1, &((PS4Texture*)(i->textures[0]))->GetAPITexture());
		currentGFXContext->setSamplers(Gnm::kShaderStagePs, 0, 1, &trilinearSampler);

		//*viewProjMat = Matrix4();
		//*viewProjMat = Matrix4::Perspective(1.0f, 1000.0f, (float)currentWidth / (float)currentHeight, 45.0f) * Matrix4::Translation(Vector3(0, 0, -2));
		float screenAspect = (float)currentWidth / (float)currentHeight;
		Matrix4 viewMatrix = gameWorld->GetMainCamera()->BuildViewMatrix();
		Matrix4 projMatrix = gameWorld->GetMainCamera()->BuildProjectionMatrix(screenAspect);
 
		*viewProjMat = projMatrix * viewMatrix;
	
		DrawRenderObject(i);
	}

	currentFrame->EndFrame();
}


void ExampleRenderer::DrawRenderObject(RenderObject* o) {
	Matrix4* modelMat = (Matrix4*)currentGFXContext->allocateFromCommandBuffer(sizeof(Matrix4), Gnm::kEmbeddedDataAlignment4);
	*modelMat = o->GetLocalTransform();

	Gnm::Buffer constantBuffer;
	constantBuffer.initAsConstantBuffer(modelMat, sizeof(Matrix4));
	constantBuffer.setResourceMemoryType(Gnm::kResourceMemoryTypeRO); // it's a constant buffer, so read-only is OK

	PS4Shader*	realShader	= (PS4Shader*)o->GetShader();
	PS4Mesh*	realMesh	= (PS4Mesh*)o->mesh;

	int objIndex = realShader->GetConstantBufferIndex("RenderObjectData");
	int camIndex = realShader->GetConstantBufferIndex("CameraData");

	currentGFXContext->setConstantBuffers(Gnm::kShaderStageVs, objIndex, 1, &constantBuffer);
	currentGFXContext->setConstantBuffers(Gnm::kShaderStageVs, camIndex, 1, &cameraBuffer);

	realShader->SubmitShaderSwitch(*currentGFXContext);
	realMesh->SubmitDraw(*currentGFXContext, Gnm::ShaderStage::kShaderStageVs);
}
