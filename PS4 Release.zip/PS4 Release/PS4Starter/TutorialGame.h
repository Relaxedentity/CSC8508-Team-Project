#pragma once
#include "ExampleRenderer.h"
#include "NavigationGrid.h"

namespace NCL {
	namespace PS4 {
		class TutorialGame {
		public:
			void InitWorld();
			TutorialGame();
			~TutorialGame();

			virtual void UpdateGame(float dt, PS4Input* input);
		protected:
			void InitialiseAssets();
			void InitCamera();
			void buildSkybox();

			void buildGameworld();

			RenderObject* AddPlayerToWorld(const Vector3& position, const Quaternion& orientation);
			RenderObject* AddCatToWorld(const Vector3& position, const Quaternion& orientation);

			RenderObject* AddFloorToWorld(const Vector3& position, const Quaternion& orientation, Vector3 halfextents);
			RenderObject* AddRebWallMainToWorld(const Vector3& position, const Quaternion& orientation, Vector3 scale);
			RenderObject* AddRebWallRightToWorld(const Vector3& position, const Quaternion& orientation, Vector3 scale, bool nodes);
			RenderObject* AddRebWallLeftToWorld(const Vector3& position, const Quaternion& orientation, Vector3 scale, bool nodes);

			void AddRebWallSquareToWorld(const Vector3& position);

			void AddRebWallNorthToWorld(const Vector3& position);
			void AddRebWallSouthToWorld(const Vector3& position);
			void AddRebWallEastToWorld(const Vector3& position);
			void AddRebWallWestToWorld(const Vector3& position);

			void AddRebWallDualVerticalToWorld(const Vector3& position);
			void AddRebWallDualHorizontalToWorld(const Vector3& position);

			void AddRebWallOpeningNorthToWorld(const Vector3& position);
			void AddRebWallOpeningSouthToWorld(const Vector3& position);
			void AddRebWallOpeningEastToWorld(const Vector3& position);
			void AddRebWallOpeningWestToWorld(const Vector3& position);

			void AddRebWallCornerNorthEastToWorld(const Vector3& position);
			void AddRebWallCornerNorthWestToWorld(const Vector3& position);
			void AddRebWallCornerSouthEastToWorld(const Vector3& position);
			void AddRebWallCornerSouthWestToWorld(const Vector3& position);

			ExampleRenderer* renderer;
			GameWorld* world;

			NavigationGrid* worldGrid;

			PS4Mesh* quadMesh;
			PS4Mesh* cubeMesh;
			PS4Mesh* sphereMesh;
			PS4Mesh* charMesh;
			PS4Mesh* enemyMesh;
			PS4Mesh* bonusMesh;
			PS4Mesh* capsuleMesh;
			PS4Mesh* gooseMesh;
			PS4Mesh* playerMesh;
			PS4Mesh* catMesh;
			PS4Mesh* corridorStraightMesh;
			PS4Mesh* corridorCornerRightSideMesh;
			PS4Mesh* corridorCornerLeftSideMesh;

			PS4Texture* catTex;
			PS4Texture* capsuleTex;
			PS4Texture* terrainTex;
			PS4Texture* corridorTex;
			PS4Texture* basicTex;
			PS4Texture* cubeTex1;
			PS4Texture* cubeTex2;
			PS4Texture* cubeTex3;
			PS4Texture* cubeTex4;
			PS4Texture* cubeTex5;
			PS4Texture* cubeTex6;

			PS4Shader* defaultShader;
		};
	}
}