#ifdef _ORBIS
#include "PS4Window.h"

using namespace NCL;
using namespace NCL::PS4;

PS4Window::PS4Window(const std::string& title, int sizeX, int sizeY, bool fullScreen, int offsetX, int offsetY)
{
	defaultSize = size = Vector2((float)sizeX, (float)sizeY);
}


PS4Window::~PS4Window()	{
}

bool PS4Window::InternalUpdate() {
	return true;
}
#endif