#ifdef _ORBIS
#include "PS4ComputeShader.h"
using namespace NCL::PS4;

PS4ComputeShader::PS4ComputeShader()
{
}


PS4ComputeShader::~PS4ComputeShader()
{
}
#endif