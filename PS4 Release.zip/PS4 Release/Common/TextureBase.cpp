#include "TextureBase.h"
using namespace NCL;
using namespace Rendering;

TextureBase::TextureBase()
{
}


TextureBase::~TextureBase()
{
}
